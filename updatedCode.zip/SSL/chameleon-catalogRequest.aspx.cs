﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Net.Mail;
using System.Net;
using RocknCode.RocknCodeLib;
using SendGrid;

namespace IChameleon
{
    public partial class chameleon_catalogRequest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                fillCombos();

            }
        }

        public void fillCombos()
        {
            try
            {
                string SQLstr = "";
                mPopulateList combo = new mPopulateList();
                //mPopulateList lBox = new mPopulateList();


                //cboState
                SQLstr = "select distinct stateName from cmStates";
                cboState = combo.fillWebCombo(cboState, mData.sDBType, SQLstr, "cmStates", false, mMain.sDataPath);

                //cboCountry
                SQLstr = "select distinct countryName from cmCountries";
                cboCountry = combo.fillWebCombo(cboCountry, mData.sDBType, SQLstr, "cmCountries", false, mMain.sDataPath);

            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error Populating Drop-down Lists");
            }
        }

        protected void butSubmit_Click(object sender, System.EventArgs e)
        {
            if (IsValidCardType(cboCardType.SelectedValue, txtCardNumber.Text.Trim()))
            {
                if (ValidateCardNumber(txtCardNumber.Text.Trim()))
                {
                    int iConfNum;
                    if (addCatRequest2(out iConfNum))
                    {

                        string sConfirmationNumber = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + "-" + iConfNum.ToString();
                        sendEConfirmation(txtEmail.Text.Trim(), txtFirstName.Text.Trim(), txtLastName.Text.Trim(), sConfirmationNumber);
                        showJSMessage("Your request has been submitted and your confirmation number sent to the provided email address");
                        closeJSWindow();

                    }
                    else
                    {
                        showJSMessage("Error Submitting Catalog Request");
                    }
                }
                else
                {
                    showJSMessage("Card Number Or Card Type Not Valid");
                }
            }
            else
            {
                showJSMessage("Card Number Or Card Type Not Valid");
            }
        }

        public bool IsValidCardType(string sCardType, string cardNumber)
        {
            // AMEX -- 34 or 37 -- 15 length
            if ((Regex.IsMatch(cardNumber, "^(34|37)"))
                && ((sCardType == "American Express")))
                return (15 == cardNumber.Length);

                // MasterCard -- 51 through 55 -- 16 length
            else if ((Regex.IsMatch(cardNumber, "^(51|52|53|54|55)"))
                && ((sCardType == "Master Card")))
                return (16 == cardNumber.Length);

                // VISA -- 4 -- 13 and 16 length
            else if ((Regex.IsMatch(cardNumber, "^(4)"))
                && ((sCardType == "Visa")))
                return (13 == cardNumber.Length || 16 == cardNumber.Length);

                // Diners Club -- 300-305, 36 or 38 -- 14 length
            else if ((Regex.IsMatch(cardNumber, "^(300|301|302|303|304|305|36|38)"))
                && ((sCardType == "Diners Club")))
                return (14 == cardNumber.Length);

                // Discover -- 6011 -- 16 length
            else if ((Regex.IsMatch(cardNumber, "^(6011)"))
                && ((sCardType == "Discover")))
                return (16 == cardNumber.Length);

            else
            {
                return false;
            }
        }

        private bool ValidateCardNumber(string cardNumber)
        {
            try
            {
                // Array to contain individual numbers
                System.Collections.ArrayList CheckNumbers = new ArrayList();
                // So, get length of card
                int CardLength = cardNumber.Length;

                // Double the value of alternate digits, starting with the second digit
                // from the right, i.e. back to front.
                // Loop through starting at the end
                for (int i = CardLength - 2; i >= 0; i = i - 2)
                {
                    // Now read the contents at each index, this
                    // can then be stored as an array of integers

                    // Double the number returned
                    CheckNumbers.Add(Int32.Parse(cardNumber[i].ToString()) * 2);
                }

                int CheckSum = 0;    // Will hold the total sum of all checksum digits

                // Second stage, add separate digits of all products
                for (int iCount = 0; iCount <= CheckNumbers.Count - 1; iCount++)
                {
                    int _count = 0;    // will hold the sum of the digits

                    // determine if current number has more than one digit
                    if ((int)CheckNumbers[iCount] > 9)
                    {
                        int _numLength = ((int)CheckNumbers[iCount]).ToString().Length;
                        // add count to each digit
                        for (int x = 0; x < _numLength; x++)
                        {
                            _count = _count + Int32.Parse(
                                ((int)CheckNumbers[iCount]).ToString()[x].ToString());
                        }
                    }
                    else
                    {
                        // single digit, just add it by itself
                        _count = (int)CheckNumbers[iCount];
                    }
                    CheckSum = CheckSum + _count;    // add sum to the total sum
                }
                // Stage 3, add the unaffected digits
                // Add all the digits that we didn't double still starting from the
                // right but this time we'll start from the rightmost number with 
                // alternating digits
                int OriginalSum = 0;
                for (int y = CardLength - 1; y >= 0; y = y - 2)
                {
                    OriginalSum = OriginalSum + Int32.Parse(cardNumber[y].ToString());
                }

                // Perform the final calculation, if the sum Mod 10 results in 0 then
                // it's valid, otherwise its false.
                return (((OriginalSum + CheckSum) % 10) == 0);
            }
            catch
            {
                return false;
            }
        }

        public bool addCatRequest(out int confirmationNum)
        {

            bool success = false;
            confirmationNum = -1;

            // declare variables
            string sConnection = null;

            // initialize ADO objects
            SqlConnection dataConn = null;
            SqlDataReader dbReader = null;
            SqlCommand dataCmd = null;

            try
            {
                mEncryption tEncrypt = new mEncryption();
                //string sCategory = cboLCategory.Text;
                byte[] arCardNumber = tEncrypt.tdesEncrypt(txtCardNumber.Text);
                byte[] arExpiration = tEncrypt.tdesEncrypt(txtExpiration.Text);
                byte[] arSCode = tEncrypt.tdesEncrypt(txtSecurityCode.Text);

                UTF8Encoding sUTFtext = new UTF8Encoding();

                sConnection = mMain.sDataPath;

                dataConn = new SqlConnection(sConnection);
                dataConn.Open();

                // set command object attributes
                dataCmd = new SqlCommand("udsp_insertCatalogRequest2", dataConn);
                dataCmd.CommandType = CommandType.StoredProcedure;

                // declare and instantiate parameters collection
                SqlParameter opReturnCode = new SqlParameter("@RETURN_VALUE", SqlDbType.Int);
                SqlParameter accountNumber = new SqlParameter("@accountNumber", SqlDbType.Int);
                SqlParameter ipCompany = new SqlParameter("@company", SqlDbType.VarChar, 100);
                SqlParameter ipFirstName = new SqlParameter("@firstName", SqlDbType.VarChar, 50);
                SqlParameter ipLastName = new SqlParameter("@lastName", SqlDbType.VarChar, 50);
                SqlParameter ipName = new SqlParameter("@name", SqlDbType.VarChar, 100);
                SqlParameter ipAddress1 = new SqlParameter("@address1", SqlDbType.VarChar, 100);
                SqlParameter ipAddress2 = new SqlParameter("@address2", SqlDbType.VarChar, 100);
                SqlParameter ipCity = new SqlParameter("@city", SqlDbType.VarChar, 50);
                SqlParameter ipState = new SqlParameter("@state", SqlDbType.VarChar, 50);
                SqlParameter ipRegion = new SqlParameter("@region", SqlDbType.VarChar, 50);
                SqlParameter ipPostalCode = new SqlParameter("@postalCode", SqlDbType.VarChar, 50);
                SqlParameter ipCountry = new SqlParameter("@country", SqlDbType.VarChar, 50);
                SqlParameter ipPhone = new SqlParameter("@phone", SqlDbType.VarChar, 50);
                SqlParameter ipEmail = new SqlParameter("@email", SqlDbType.VarChar, 50);
                SqlParameter ipCardType = new SqlParameter("@cardType", SqlDbType.VarChar, 50);
                SqlParameter ipCardNumber = new SqlParameter("@cardNumber", SqlDbType.VarBinary, 32);
                SqlParameter ipExpireDate = new SqlParameter("@expireDate", SqlDbType.VarBinary, 32);
                SqlParameter ipSecurityCode = new SqlParameter("@securityCode", SqlDbType.VarBinary, 32);
                SqlParameter ipDateRequested = new SqlParameter("@dateRequested", SqlDbType.DateTime);
                SqlParameter ipDownloaded = new SqlParameter("@downloaded", SqlDbType.Bit);
                SqlParameter ipProcessed = new SqlParameter("@processed", SqlDbType.Bit);
                SqlParameter ipProcessedBy = new SqlParameter("@processedBy", SqlDbType.VarChar, 50);
                SqlParameter ipSource = new SqlParameter("@source", SqlDbType.VarChar, 50);
                SqlParameter ipConfirmation = new SqlParameter("@confirmation", SqlDbType.Int);

                // specify parameter direction
                opReturnCode.Direction = ParameterDirection.ReturnValue;
                accountNumber.Direction = ParameterDirection.Input;
                ipCompany.Direction = ParameterDirection.Input;
                ipFirstName.Direction = ParameterDirection.Input;
                ipLastName.Direction = ParameterDirection.Input;
                ipName.Direction = ParameterDirection.Input;
                ipAddress1.Direction = ParameterDirection.Input;
                ipAddress2.Direction = ParameterDirection.Input;
                ipCity.Direction = ParameterDirection.Input;
                ipState.Direction = ParameterDirection.Input;
                ipRegion.Direction = ParameterDirection.Input;
                ipPostalCode.Direction = ParameterDirection.Input;
                ipCountry.Direction = ParameterDirection.Input;
                ipPhone.Direction = ParameterDirection.Input;
                ipEmail.Direction = ParameterDirection.Input;
                ipCardType.Direction = ParameterDirection.Input;
                ipCardNumber.Direction = ParameterDirection.Input;
                ipExpireDate.Direction = ParameterDirection.Input;
                ipSecurityCode.Direction = ParameterDirection.Input;
                ipDateRequested.Direction = ParameterDirection.Input;
                ipDownloaded.Direction = ParameterDirection.Input;
                ipProcessed.Direction = ParameterDirection.Input;
                ipProcessedBy.Direction = ParameterDirection.Input;
                ipSource.Direction = ParameterDirection.Input;
                ipConfirmation.Direction = ParameterDirection.Output;

                // initialize parameter values					
                accountNumber.Value = 0;
                ipCompany.Value = txtCompany.Text;
                ipFirstName.Value = txtFirstName.Text;
                ipLastName.Value = txtLastName.Text;
                ipName.Value = txtName.Text;
                ipAddress1.Value = txtAddress1.Text;
                ipAddress2.Value = txtAddress2.Text;
                ipCity.Value = txtCity.Text;
                ipState.Value = cboState.SelectedItem.Text;
                ipRegion.Value = txtRegion.Text; ;
                ipPostalCode.Value = txtPostalCode.Text;
                ipCountry.Value = cboCountry.SelectedItem.Text;
                ipPhone.Value = txtPhone.Text;
                ipEmail.Value = txtEmail.Text;
                ipCardType.Value = cboCardType.SelectedItem.Text;
                ipCardNumber.Value = arCardNumber;
                ipExpireDate.Value = arExpiration;
                ipSecurityCode.Value = arSCode;
                ipDateRequested.Value = System.DateTime.Now;
                ipDownloaded.Value = 0;
                ipProcessed.Value = 0;
                ipProcessedBy.Value = System.DBNull.Value;
                ipSource.Value = "Website";

                // add parameters to collection
                dataCmd.Parameters.Add(opReturnCode);
                dataCmd.Parameters.Add(accountNumber);
                dataCmd.Parameters.Add(ipCompany);
                dataCmd.Parameters.Add(ipFirstName);
                dataCmd.Parameters.Add(ipLastName);
                dataCmd.Parameters.Add(ipName);
                dataCmd.Parameters.Add(ipAddress1);
                dataCmd.Parameters.Add(ipAddress2);
                dataCmd.Parameters.Add(ipCity);
                dataCmd.Parameters.Add(ipState);
                dataCmd.Parameters.Add(ipRegion);
                dataCmd.Parameters.Add(ipPostalCode);
                dataCmd.Parameters.Add(ipCountry);
                dataCmd.Parameters.Add(ipPhone);
                dataCmd.Parameters.Add(ipEmail);
                dataCmd.Parameters.Add(ipCardType);
                dataCmd.Parameters.Add(ipCardNumber);
                dataCmd.Parameters.Add(ipExpireDate);
                dataCmd.Parameters.Add(ipSecurityCode);
                dataCmd.Parameters.Add(ipDateRequested);
                dataCmd.Parameters.Add(ipDownloaded);
                dataCmd.Parameters.Add(ipProcessed);
                dataCmd.Parameters.Add(ipProcessedBy);
                dataCmd.Parameters.Add(ipSource);
                dataCmd.Parameters.Add(ipConfirmation);


                //showJSMessage(ipEmail.Value.ToString() + " DB Call");
                // execute command
                dataCmd.ExecuteReader();


                // test return value and transfer control as necessary
                if ((int)dataCmd.Parameters[0].Value == 1)
                {
                    success = false;

                }	// end if
                if ((int)dataCmd.Parameters[0].Value == 9)
                {
                    confirmationNum = (int)ipConfirmation.Value;
                    success = true;

                }	// end if

            }	//end try
            catch (SqlException sqle)
            {
                throw sqle;

            }	//end catch 
            catch (Exception z)
            {
                throw z;

            }	//end catch 
            finally
            {
                // clean up
                if (dbReader != null)
                {
                    dbReader.Close();

                }	// end if

                dataConn.Close();
                dataConn.Dispose();
                dataCmd.Dispose();

            }	// end finally

            return success;
        }

        public bool addCatRequest2(out int confirmationNum)
        {
            bool success = false;
            confirmationNum = -1;
            int catReqID = 0;

            // initialize ADO objects
            SqlConnection dataConn = null;
            SqlDataReader dbReader = null;
            SqlCommand dataCmd = null;
            SqlTransaction trans = null;

            try
            {
                mEncryption tEncrypt = new mEncryption();
                //string sCategory = cboLCategory.Text;
                byte[] arCardNumber = tEncrypt.tdesEncrypt(txtCardNumber.Text);
                byte[] arExpiration = tEncrypt.tdesEncrypt(txtExpiration.Text);
                byte[] arSCode = tEncrypt.tdesEncrypt(txtSecurityCode.Text);

                UTF8Encoding sUTFtext = new UTF8Encoding();

                // set connection attributes and open data connection
                dataConn = new SqlConnection(mMain.chamDataPath);
                dataConn.Open();
                trans = dataConn.BeginTransaction();

                // set command object attributes
                dataCmd = new SqlCommand("udsp_SaveCatalogRequest", dataConn, trans);
                dataCmd.CommandType = CommandType.StoredProcedure;

                // declare and instantiate parameters collection
                dataCmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                dataCmd.Parameters.AddWithValue("@catRequestID", catReqID);
                dataCmd.Parameters.AddWithValue("@accountNumber", 0);
                dataCmd.Parameters.AddWithValue("@company", txtCompany.Text.Trim());
                dataCmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                dataCmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                dataCmd.Parameters.AddWithValue("@address1", txtAddress1.Text.Trim());
                dataCmd.Parameters.AddWithValue("@address2", txtAddress2.Text.Trim());
                dataCmd.Parameters.AddWithValue("@city", txtCity.Text.Trim());
                dataCmd.Parameters.AddWithValue("@state", cboState.SelectedItem.Text.Trim());
                dataCmd.Parameters.AddWithValue("@region", txtRegion.Text.Trim());
                dataCmd.Parameters.AddWithValue("@postalCode", txtPostalCode.Text.Trim());
                dataCmd.Parameters.AddWithValue("@country", cboCountry.SelectedItem.Text.Trim());

                dataCmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                dataCmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                dataCmd.Parameters.AddWithValue("@nameOnCard", txtName.Text.Trim());
                dataCmd.Parameters.AddWithValue("@cardType", cboCardType.SelectedItem.Text.Trim());
                dataCmd.Parameters.AddWithValue("@cardNumber", arCardNumber);
                dataCmd.Parameters.AddWithValue("@expireDate", arExpiration);
                dataCmd.Parameters.AddWithValue("@securityCode", arSCode);
                dataCmd.Parameters.AddWithValue("@dateRequested", System.DateTime.Now);
                dataCmd.Parameters.AddWithValue("@source", "Website");
                dataCmd.Parameters.AddWithValue("@payment", System.DBNull.Value);
                dataCmd.Parameters.AddWithValue("@datePaid", System.DBNull.Value);
                dataCmd.Parameters.AddWithValue("@processed", 0);
                dataCmd.Parameters.AddWithValue("@processedBy", System.DBNull.Value);
                dataCmd.Parameters.AddWithValue("@shipped", 0);
                dataCmd.Parameters.AddWithValue("@shipDate", System.DBNull.Value);

                dataCmd.Parameters.Add("@recordID", SqlDbType.Int).Direction = ParameterDirection.Output;


                // execute command
                dataCmd.ExecuteNonQuery();

                // test return value and transfer control as necessary
                if ((int)dataCmd.Parameters[0].Value == 9)
                {
                    success = true;
                    confirmationNum = Convert.ToInt32(dataCmd.Parameters["@recordID"].Value);
                    trans.Commit();
                }
                else
                {
                    trans.Rollback();
                    throw new Exception("Error Submitting Credit Card Information");

                }	// end if

            }	//end try
            catch (SqlException sqle)
            {
                trans.Rollback();
                throw new Exception("SqlException: " + sqle.Message);

            }	//end catch 
            catch (Exception z)
            {
                trans.Rollback();
                throw new Exception("Generic Exception: " + z.Message);

            }	//end catch 
            finally
            {
                // clean up
                if (dbReader != null)
                {
                    dbReader.Close();

                }	// end if

                dataConn.Close();
                dataConn.Dispose();
                dataCmd.Dispose();

            }	// end finally

            return success;

        }

        //Inserts new catalog request record into database by executing SQL statement
        //			private bool addCatRequest()
        //			{
        //				string sConn;
        //				string sSql;
        //
        //				mEncryption tEncrypt = new mEncryption();
        //		
        //				//string sCategory = cboLCategory.Text;
        //				byte[] arCardNumber = tEncrypt.tdesEncrypt(txtCardNumber.Text);
        //				byte[] arExpiration = tEncrypt.tdesEncrypt(txtExpiration.Text);
        //				byte[] arSCode = tEncrypt.tdesEncrypt(txtSecurityCode.Text);
        //
        //				UTF8Encoding sUTFtext = new UTF8Encoding();
        //								
        //				// Test database insert
        //				sConn = mMain.sDataPath;
        //				sSql = "INSERT chaCatalogRequests (memberID, name, address1, address2, city, state, region, postalCode, country, phone, email," + 
        //					"cardType, cardNumber, expireDate, securityCode, dateRequested, downloaded, processed, processedBy) VALUES (@memberID, @name, @address1, @address2, @city," +
        //					"@state, @region, @postalCode, @country, @phone, @email, @cardType, @cardNumber, @expireDate, @securityCode, @dateRequested, @downloaded, @processed, @processedBy)";
        //				SqlConnection conn = new SqlConnection(sConn);
        //				SqlCommand cmd = new SqlCommand(sSql, conn);
        //
        //				//Declare parameters
        //				SqlParameter param1;
        //				SqlParameter param2;
        //				SqlParameter param3;
        //				SqlParameter param4;
        //				SqlParameter param5;
        //				SqlParameter param6;
        //				SqlParameter param7;
        //				SqlParameter param8;
        //				SqlParameter param9;
        //				SqlParameter param10;
        //				SqlParameter param11;
        //				SqlParameter param12;
        //				SqlParameter param13;
        //				SqlParameter param14;
        //				SqlParameter param15;
        //				SqlParameter param16;
        //				SqlParameter param17;
        //				SqlParameter param18;
        //				SqlParameter param19;
        //				//SqlParameter param20;
        //				
        //
        //				//Define parameters' data types
        //				param1 = cmd.Parameters.Add("@memberID", SqlDbType.Int);
        //				param2 = cmd.Parameters.Add("@name", SqlDbType.VarChar, 50);
        //				param3 = cmd.Parameters.Add("@address1", SqlDbType.VarChar, 100);
        //				param4 = cmd.Parameters.Add("@address2", SqlDbType.VarChar, 100);
        //				param5 = cmd.Parameters.Add("@city", SqlDbType.VarChar, 50);
        //				param6 = cmd.Parameters.Add("@state", SqlDbType.VarChar, 50);
        //				param7 = cmd.Parameters.Add("@region", SqlDbType.VarChar, 50);
        //				param8 = cmd.Parameters.Add("@postalCode", SqlDbType.VarChar, 50);
        //				param9 = cmd.Parameters.Add("@country", SqlDbType.VarChar, 50);
        //				param10 = cmd.Parameters.Add("@phone", SqlDbType.VarChar, 50);
        //				param11 = cmd.Parameters.Add("@email", SqlDbType.VarChar, 50);
        //				param12 = cmd.Parameters.Add("@cardType", SqlDbType.VarChar, 50);
        //				param13 = cmd.Parameters.Add("@cardNumber", SqlDbType.VarBinary,32);
        //				param14 = cmd.Parameters.Add("@expireDate", SqlDbType.VarBinary,32);
        //				param15 = cmd.Parameters.Add("@securityCode", SqlDbType.VarBinary,32);
        //				param16 = cmd.Parameters.Add("@dateRequested", SqlDbType.DateTime);
        //				param17 = cmd.Parameters.Add("@downloaded", SqlDbType.Bit);
        //				param18 = cmd.Parameters.Add("@processed", SqlDbType.Bit);
        //				param19 = cmd.Parameters.Add("@processedBy", SqlDbType.VarChar, 50);
        //				//param1 = cmd.Parameters.Add("@confNumber", SqlDbType.Int);
        //				
        //
        //				//Assign parameters' values
        //				param1.Value = 0;
        //				param2.Value = txtName.Text;
        //				param3.Value = txtAddress1.Text;
        //				param4.Value = txtAddress2.Text;
        //				param5.Value = txtCity.Text;
        //				param6.Value = cboState.SelectedItem.Text;
        //				param7.Value = txtRegion.Text;;
        //				param8.Value = txtPostalCode.Text;
        //				param9.Value = cboCountry.SelectedItem.Text;
        //				param10.Value = txtPhone.Text;
        //				param11.Value = txtEmail.Text;
        //				param12.Value = cboCardType.SelectedItem.Text;
        //				param13.Value = arCardNumber;
        //				param14.Value = arExpiration;
        //				param15.Value = arSCode;
        //				param16.Value = System.DateTime.Now;
        //				param17.Value = 0;
        //				param18.Value = 0;
        //				param19.Value = System.DBNull.Value;
        //
        //				try
        //				{
        //					//Open db connection and execute stored proc
        //					conn.Open();
        //					cmd.ExecuteNonQuery();
        //					//showJSMessage(rows.ToString() + " rows inserted");
        //					return true;
        //				}
        //				catch(Exception err)
        //				{
        //					showJSMessage(err.ToString());
        //					return false;
        //				}
        //				finally
        //				{
        //					//close db connection
        //					conn.Close();
        //				}
        //			}

        private void showJSMessage(string sMessage)
        {
            System.Text.StringBuilder sbMsg = new System.Text.StringBuilder();
            sbMsg.Append("<script language=javascript>");
            sbMsg.Append(" alert('");
            sbMsg.Append(sMessage);
            sbMsg.Append("')");
            sbMsg.Append("</script>");
            Response.Write(sbMsg.ToString());
        }

        private void closeJSWindow()
        {
            System.Text.StringBuilder jScript = new System.Text.StringBuilder();
            jScript.Append("<script language=\"JavaScript\">");
            jScript.Append("window.close()");
            jScript.Append(";");
            jScript.Append("</script>");

            this.RegisterClientScriptBlock("closeWindow", jScript.ToString());
        }

        private void sendEConfirmation(string sEmailAddress, string sFirstName, string sLastName, string sConfirmation)
        {
            //string message = readHtmlPage(ViewState["url"].ToString());

            string message = "";

            //Trace.Write("Submit", "Page is valid -- send email.");

            try
            {
                var regMessage = new SendGridMessage();

                message = "Thank you " + sFirstName + " " + sLastName + " for ordering Chameleon's Signature Line catalog."
                    + "<br>Your catalog will be shipped to the address provided within the next few weeks."
                    + "<br><br>Your confirmation number is: <b>" + sConfirmation + "</b>"
                    + "<br><br>Regards,"
                    + "<br>Chameleon"
                    + "<br><br>Chameleon Fine Lighting"
                    + "<br>223 East 59th Street"
                    + "<br>New York, NY  10022"
                    + "<br>tel: 212-355-6300"
                    + "<br><br>email: membersupport@chameleon59.com"
                    + "<br>website: www.chameleon59.com";

                //SmtpClient mailClient = new SmtpClient();
                //mailClient.Host = mMain.smtpServer;
                //mailClient.Port = mMain.smtpPort;


                string sFrom = "donotreply@chameleonmailer.com"; ;
                string sSubject = "Chameleon Catalog Request";
                string sCc = "membersupport@chameleon59.com";
                string sBcc = String.Empty;
                string userName = mMain.sendGridUser;
                string pw = mMain.sendGridPw;

                regMessage.AddTo(sEmailAddress);
                regMessage.From = new MailAddress(sFrom);
                regMessage.Subject = sSubject;
                regMessage.AddCc(sCc);
                regMessage.Html = message;
                //regMessage.Html 

                NetworkCredential netUser = new NetworkCredential(userName, pw);
                var transportWeb = new Web(netUser);
                transportWeb.DeliverAsync(regMessage);


                //MailMessage m = new MailMessage();

                //m.From = new MailAddress(sFrom);
                //m.Subject = sSubject;
                //MailAddress to = new MailAddress(sEmailAddress);
                //m.To.Add(to);
                //m.CC.Add(sCc);
                ////MailAddress bcc = new MailAddress(sBcc);
                ////m.Bcc.Add(bcc);

                //m.Body = message;
                //m.IsBodyHtml = true;

                //NetworkCredential netUser = new NetworkCredential(userName, pw);
                //mailClient.UseDefaultCredentials = false;
                //mailClient.Credentials = netUser;

                //mailClient.Send(m);


                //Mailer.From = "mail@chameleon59.com";
                //Mailer.To = sEmailAddress;
                //Mailer.Bcc = "membersupport@chameleon59.com;mail@chameleon59.com;mscoglio@chameleon59.com;lleconte@chameleon59.com";
                //Mailer.Subject = "Chameleon Catalog Request";
                //Mailer.Body = message;
                //Mailer.BodyFormat = System.Web.Mail.MailFormat.Html;					
                //SmtpMail.Send(Mailer);
                //lbInfo.Text = "Catalog Request Submitted!";
                //showJSMessage("Catalog Request Submitted!");
                //closeJSWindow();

                //litSent.Text = message;
            }
            catch (SmtpException smtpEx)
            {
                lbInfo.Text = "An error occurred: " + smtpEx.ToString();
                lbInfo.Visible = true;

                showJSMessage("An error occurred: " + smtpEx.ToString());
            }
            catch (Exception ex)
            {
                lbInfo.Text = "An error occurred: " + ex.ToString();
                showJSMessage("An error occurred: " + ex.ToString());
                closeJSWindow();
            }

        }
    }
}