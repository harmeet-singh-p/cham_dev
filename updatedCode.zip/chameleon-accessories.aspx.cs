﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RocknCode.RocknCodeLib;
using System.Data;
using System.Web.SessionState;

namespace IChameleon
{
    public partial class chameleon_accessories : System.Web.UI.Page
    {
        #region User Defined Decs

        private string sWhere = "";
        private string sSearchHeading = "Accessory Line > ";
        //private string sStatus = "(status = 'Available' or status = 'On Hold' or status = '4-6 weeks' or status = '6-8 weeks' or status = '8-12 weeks'  or (DATEDIFF (day,dateUpdated,getdate() ) <= 14 and status = 'Sold') ) and (isChild = 0)";
        private string sStatus = "(webEnabled = 1)";
        protected System.Web.UI.HtmlControls.HtmlInputImage butLoginRegister_B;

        #endregion
         

        protected void Page_Load(object sender, System.EventArgs e)
        {
           
            if (!Page.IsPostBack)
                fillCombos();

            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetAllowResponseInBrowserHistory(false);
        }

        public void fillCombos()
        {
            try
            {
                string SQLstr = "";
                mPopulateList combo = new mPopulateList();

                // cboStyles
                //					SQLstr = "select distinct style from chaStyles order by style";
                //					cboStyles = combo.fillWebCombo(cboStyles, mData.sDBType, SQLstr, "chaStyles", true, mMain.sDataPath);

                // cboAccessories
                SQLstr = "select distinct subCategory, categoryID from chaItemCategories where mainCategory = 'Accessories' order by categoryID";
                //cboAccessories = combo.fillWebCombo(cboAccessories, mData.sDBType, SQLstr, "chaItemCategories", true, mMain.sDataPath);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error Populating Drop-down Lists");
            }
        }

        protected void cboAccessories_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            //sSearchHeading = sSearchHeading + "Accessories > " + cboAccessories.SelectedItem;
            //sWhere = "";
            //if (cboAccessories.SelectedValue == "All")
            //{
            //    sWhere = Server.UrlEncode(" Where (category = 'Accessories')");
            //}
            //else
            //{
            //    sWhere = Server.UrlEncode(" Where (category = 'Accessories' and subCategory = '" + cboAccessories.SelectedValue + "')");
            //}
            Response.Redirect("chameleon-searchresults.aspx?line=Accessories&heading=" + sSearchHeading + "&where=" + sWhere, true);

        }

        //protected void butLoginRegister_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    if (IsLoggedIn())
        //    {
        //        Session["memberID"] = null;
        //        Response.Redirect("chameleon-home.aspx", true);
        //    }
        //    else
        //    {
        //        Response.Redirect("chameleon-memberLogin.aspx", true);
        //    }
        //}

        private bool IsLoggedIn()
        {
            //string s = Session["memberID"].ToString();
            if (Session["memberID"] != null && Session["memberID"].ToString() != "")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //protected void butMyWorkshop_B_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-memberHome.aspx", true);
        //}

        //protected void butAllInventory_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-searchResults.aspx?Line=All", true);
        //}

        //protected void butAllAntiques_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-searchResults.aspx?Line=Antiques", true);
        //}

        //protected void butAllSignature_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-searchResults.aspx?Line=Signature", true);
        //}

        //protected void butRequestCatalog_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-catalogRequest.aspx", true);
        //}

        //protected void butAdvancedSearch_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-advancedSearch.aspx", true);
        //}

        //protected void butRecentArrivals_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-recentArrivals.aspx", true);
        //}


        //protected void butMyProfile_B_ServerClick(object sender, ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-memberProfile.aspx", true);
        //}



        //ADDED BY ROB START

        //protected void butTraditional_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-searchResults.aspx?Line=Traditional", true);
        //}

        //protected void butContemporary_ServerClick(object sender, System.Web.UI.ImageClickEventArgs e)
        //{
        //    Response.Redirect("chameleon-searchResults.aspx?Line=Contemporary", true);
        //}

        //ADDED BY ROB END
    }
}