﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using RocknCode.RocknCodeLib;
using System.Web.SessionState;
using System.IO;

namespace IChameleon
{

    public partial class chameleonMaster : System.Web.UI.MasterPage
    {
        #region User Defined Decs

        private string sWhere = String.Empty;
        private string sType = "Signature";
        private string sSearchHeading = "Signature Line > ";
        //private string sStatus = "(status = 'Available' or status = 'On Hold' or status = '4-6 weeks' or status = '6-8 weeks' or status = '8-12 weeks'  or (DATEDIFF (day,dateUpdated,getdate() ) <= 14 and status = 'Sold') ) and (isChild = 0)";
        private string sStatus = "(webEnabled = 1)";
        public DataSet mDataSet = new DataSet();
        private SqlConnection mConn;
        private SqlDataAdapter mAdapter = new SqlDataAdapter();
        public bool blIsLoggedIn = false;
        public string bgImage = String.Empty;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            //cboState
            if (!Page.IsPostBack)
            {
                string SQLstr = "";
                mPopulateList combo = new mPopulateList();
                SQLstr = "select distinct stateName from cmStates";
                cboState = combo.fillWebCombo(cboState, mData.sDBType, SQLstr, "cmStates", false, mMain.sDataPath);
            }

        }

        protected void butSubmit_Click(object sender, System.EventArgs e)
        {
            insertConsultationInfo();
        }

        public bool insertConsultationInfo()
        {
            bool success = false;
            
            // initialize ADO objects
            SqlConnection dataConn = null;
            SqlDataReader dbReader = null;
            SqlCommand dataCmd = null;
            SqlTransaction trans = null;

            try
            {
                mEncryption tEncrypt = new mEncryption();
                

                // set connection attributes and open data connection
                dataConn = new SqlConnection(mMain.sDataPath);
                dataConn.Open();
                trans = dataConn.BeginTransaction();

                // set command object attributes
                dataCmd = new SqlCommand("usp_InsertchaConsultationInfo", dataConn, trans);
                dataCmd.CommandType = CommandType.StoredProcedure;

                // declare and instantiate parameters collection                
                dataCmd.Parameters.AddWithValue("@FullName", txtUserName.Text.Trim());
                dataCmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                dataCmd.Parameters.AddWithValue("@PhoneNumber", txtPhoneNumber.Text.Trim());                
                dataCmd.Parameters.AddWithValue("@City", txtCity.Text.Trim());
                dataCmd.Parameters.AddWithValue("@State", cboState.SelectedItem.Text.Trim());
                
                dataCmd.Parameters.AddWithValue("@HelpMessage", txtArea.Text.Trim());
                dataCmd.Parameters.AddWithValue("@SubscribeNewsletter", chbxSubscribe.Checked ? 1 : 0);                

                dataCmd.Parameters.Add("@confirmation", SqlDbType.Int).Direction = ParameterDirection.Output;


                // execute command
                var abc = dataCmd.ExecuteNonQuery();

                // test return value and transfer control as necessary
                if ((int)dataCmd.Parameters[0].Value == 9)
                {
                    success = true;                   
                    trans.Commit();
                }
                else
                {
                    trans.Rollback();
                    throw new Exception("Error Submitting Credit Card Information");

                }	// end if

            }	//end try
            catch (SqlException sqle)
            {
                trans.Rollback();
                throw new Exception("SqlException: " + sqle.Message);

            }	//end catch 
            catch (Exception z)
            {
                trans.Rollback();
                throw new Exception("Generic Exception: " + z.Message);

            }	//end catch 
            finally
            {
                // clean up
                if (dbReader != null)
                {
                    dbReader.Close();

                }	// end if

                dataConn.Close();
                dataConn.Dispose();
                dataCmd.Dispose();

            }	// end finally

            return success;

        }

        //protected string randomImage(string imageDir)
        //{
        //    //DirectoryInfo dI = new DirectoryInfo(Server.MapPath("~/Images/Background/"));
        //    //FileInfo [] fI = dI.GetFiles();
        //    //Random rdm = new Random();

        //    //int index = rdm.Next(0, fI.Length);

        //    //return fI[index].Name;



        //}

        protected void mnuQuickSrch_MenuItemClick(object sender, MenuEventArgs e)
        {
            switch (e.Item.Text)
            {
                case "Browse All":
                    {

                        Response.Redirect("chameleon-searchResults.aspx?Line=Signature");
                        break;
                    }

                case "Modern":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Modern') and " + sStatus);

                        break;
                    }
                case "Traditional":
                    {
                        Response.Redirect("chameleon-searchResults.aspx?Line=Traditional", true);

                        break;
                    }
                case "Kitchen":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Kitchen') and " + sStatus);

                        break;
                    }
                case "Bathroom":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Bathroom') and " + sStatus);

                        break;
                    }

                case "Dining Room":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Dining Room')"); //and " + sStatus);
                        break;
                    }
                case "Foyer/Hallway":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Hallway') and " + sStatus);
                        break;
                    }
                case "Outdoor":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Outdoor') and " + sStatus);
                        break;
                    }
                case "Contemporary":
                    {
                        Response.Redirect("chameleon-searchResults.aspx?Line=Contemporary", true);
                        break;
                    }
                case "Recent Arrivals":
                    {
                        Response.Redirect("chameleon-recentArrivals.aspx", true);
                        break;
                    }


            }

            if (sWhere != String.Empty)
            {
                Response.Redirect("chameleon-searchresults.aspx?Line=Custom&heading=" + sSearchHeading + "&where=" + sWhere, true);
            }


        }

        protected void mnuSignature_MenuItemClick(object sender, MenuEventArgs e)
        {
            switch (e.Item.Text)
            {
                case "Browse All":
                    {

                        Response.Redirect("chameleon-searchResults.aspx?Line=Signature");
                        break;
                    }

                case "Ceiling":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Ceiling') and " + sStatus);

                        break;
                    }
                case "Chandelier":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Ceiling' and subCategory = 'Chandelier') and " + sStatus);

                        break;
                    }
                case "Lantern":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Ceiling' and subCategory = 'Lantern') and " + sStatus);

                        break;
                    }
                case "Pendant":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Ceiling' and subCategory = 'Pendant') and " + sStatus);

                        break;
                    }

                case "Wall":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Wall') and " + sStatus);
                        break;
                    }
                case "1-Light":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Wall' and subCategory = '1-Light Sconce') and " + sStatus);
                        break;
                    }
                case "2-Light":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Wall' and subCategory = '2-Light Sconce') and " + sStatus);
                        break;
                    }
                case "3-Light":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Wall' and subCategory = '3-Light Sconce') and " + sStatus);
                        break;
                    }
                case "Shaded":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Wall' and subCategory = 'Shade') and " + sStatus);
                        break;
                    }
                case "Table":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Table') and " + sStatus);
                    }

                    break;
                case "Floor":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and category = 'Floor') and " + sStatus);
                    }

                    break;
                case "Kitchen":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Kitchen') and " + sStatus);

                        break;
                    }
                case "Bathroom":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Bathroom') and " + sStatus);

                        break;
                    }

                case "Dining Room":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Dining Room')"); //and " + sStatus);
                        break;
                    }
                case "Foyer/Hallway":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Hallway') and " + sStatus);
                        break;
                    }
                case "Outdoor":
                    {
                        sWhere = Server.UrlEncode(" Where (type = '" + sType + "' and collectionName = 'Outdoor') and " + sStatus);
                        break;
                    }
               

            }

            if ( sWhere != String.Empty)
            {
                Response.Redirect("chameleon-searchresults.aspx?Line=Custom&heading=" + sSearchHeading + "&where=" + sWhere, true);
            }
        
            

        }

        protected void lbtnMyWkshop_Click(object sender, EventArgs e)
        {
            Response.Redirect("chameleon-memberHome.aspx", true);
        }

        protected void lbtnMyProfile_Click(object sender, EventArgs e)
        {
            Response.Redirect("chameleon-memberProfile.aspx", true);
        }

        protected void lbtnLogin_Click(object sender, EventArgs e)
        {
            if (Session["memberID"] != null)
            {
                logOff();
                Response.Redirect("chameleon-home.aspx");
            }
            else
            {
                Response.Redirect("chameleon-memberLogin.aspx");
            }
        }

        private void logOff()
        {
            Session["memberID"] = null;

        }

        protected void butSubmit_Click(object sender, ImageClickEventArgs e)
        {
            //sSearchHeading = "All Lines > Item Code > " + txtItemNo.Text;
            //sWhere = "";

            //if (txtItemNo.Text != "")
            //{
            //    string keyWord = txtItemNo.Text.Trim();
            //    sWhere = Server.UrlEncode(" where (itemCode LIKE '%" + keyWord + "%' or itemNumber LIKE '%" + keyWord + "%' or item LIKE '%" + keyWord + "%' or description LIKE '%" + keyWord + "%') and " + sStatus);
            //    Response.Redirect("chameleon-searchresults.aspx?Line=custom&heading=" + sSearchHeading + "&where=" + sWhere, true);

            //}
        }

        protected void butReset_Click(object sender, ImageClickEventArgs e)
        {
             //txtItemNo.Text = String.Empty;
        }

        

        
        

    }
}