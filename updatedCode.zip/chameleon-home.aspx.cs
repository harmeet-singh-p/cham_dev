﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web.SessionState;
using System.Data.SqlClient;
using RocknCode.RocknCodeLib;


namespace IChameleon
{
    public partial class chameleon_home : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            if (HttpContext.Current.Request.UserAgent.ToLower().Contains("ipad") || HttpContext.Current.Request.UserAgent.ToLower().Contains("iphone") || HttpContext.Current.Request.UserAgent.ToLower().Contains("MAC OS X"))
            {
                //iPad is the requested client. 
                Server.Transfer("chameleon-home2.aspx");
            }                   


        }           

       
    }
}