﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ImageResizer;

namespace IChameleon
{
    public partial class chameleon_sustainability : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



            //ImageBuilder.Current.Build("~/images/sustainabliity.jpg", "~/images/sustainabliity.jpg",
            //                 new ResizeSettings("width=100&height=200&crop=auto"));
            //Image1.ImageUrl = "~/images/sustainabliity.jpg";

            //ImageBuilder.Current.Build(Image1, Image1,
            //                 new ResizeSettings("width=100&height=200&crop=auto"));


            //if (Page.IsPostBack && !string.IsNullOrEmpty(img1.Value)) Response.Redirect(ResolveUrl(img1.Value));

        }
    }
}