using System;
using System.IO;
using System.Security;
using System.Security.Cryptography;
using System.Text;

namespace IChameleon
{
	/// <summary>
	/// Summary description for mEncryption.
	/// </summary>
	public class mEncryption
	{
		public mEncryption()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public byte[] tdesEncrypt(string sPlainText)
		 {
			 byte[] arResult;
			 UTF8Encoding uEncoder = new UTF8Encoding();
			 byte [] arInput = uEncoder.GetBytes(sPlainText);

			 TripleDESCryptoServiceProvider tdesProvider = new TripleDESCryptoServiceProvider();
			 ICryptoTransform cTransform = tdesProvider.CreateEncryptor(this.tdesKey, this.tdesIV);
			
			 MemoryStream mStream = new MemoryStream();
			 CryptoStream cStream = new CryptoStream(mStream, cTransform, CryptoStreamMode.Write);

			 cStream.Write(arInput, 0, arInput.Length);			

			 cStream.FlushFinalBlock();
			 mStream.Position = 0;

			 arResult = new byte[mStream.Length];
			
			 mStream.Read(arResult, 0, (int)(mStream.Length));
			 cStream.Close();

			 //UTF8Encoding sUTFtext = new UTF8Encoding();
			 tdesDecrypt(arResult);			
			
			 return arResult;

		 }

		public string tdesEncryptString(string sPlainText)
		{
			byte[] arResult;
			UTF8Encoding uEncoder = new UTF8Encoding();
			byte [] arInput = uEncoder.GetBytes(sPlainText);

			TripleDESCryptoServiceProvider tdesProvider = new TripleDESCryptoServiceProvider();
			ICryptoTransform cTransform = tdesProvider.CreateEncryptor(this.tdesKey, this.tdesIV);
			
			MemoryStream mStream = new MemoryStream();
			CryptoStream cStream = new CryptoStream(mStream, cTransform, CryptoStreamMode.Write);

			cStream.Write(arInput, 0, arInput.Length);			

			cStream.FlushFinalBlock();
			mStream.Position = 0;

			arResult = new byte[mStream.Length];
			
			mStream.Read(arResult, 0, (int)(mStream.Length));
			cStream.Close();

			//UTF8Encoding sUTFtext = new UTF8Encoding();
			tdesDecrypt(arResult);			
			
			return Convert.ToBase64String(arResult);

		}

		public string tdesDecrypt(byte[] arInput)
		{
						
			TripleDESCryptoServiceProvider tdesProvider = new TripleDESCryptoServiceProvider();
			ICryptoTransform cTransform = tdesProvider.CreateDecryptor(this.tdesKey, this.tdesIV);
			
			MemoryStream mStream = new MemoryStream();
			CryptoStream cStream = new CryptoStream(mStream, cTransform, CryptoStreamMode.Write);

			cStream.Write(arInput, 0, arInput.Length);
			cStream.FlushFinalBlock();
			mStream.Position = 0;

			byte[] arResult = new byte[mStream.Length];

			mStream.Read(arResult, 0, (int)(mStream.Length));
			cStream.Close();

			UTF8Encoding sUTFtext = new UTF8Encoding();
			return sUTFtext.GetString(arResult);	


		}


		//these byte arrays will contain the 'KEY' and 'Vector' used in
		//encryption and decryption .
		private byte [] tdesKey = null;
		private byte[] tdesIV = null;

	}
	
}
