using System;
using System.Data.SqlClient;
using System.Collections;
using System.ComponentModel;
using System.Data;
using RocknCode.RocknCodeLib;



namespace IChameleon
	{
		/// <summary>
		/// Summary description for mMain.
		/// </summary>
		/// 
		// Global Enumerator containing actions that can be performed on a dataset
		public enum DatasetAction{AddNew, Cancel, Update, Edit, Delete, None, Move, Sort};

		public class mMain
		{
			//*********************		Global objects		******************************/

			//public static mData mData1;
			public static mData mData1 = new mData();

            public static string sDataPath = @"Data Source=localhost; Database=cham_dev; Integrated Security=True;";


            public static string chamDataPath = string.Empty;

			public static string sProductSource = "chaProducts";
			
            public static string sRegistrationLink = "http://www.chameleonhome.com/chameleon-memberLogin.aspx"; //LIVE WEBSITE
			
			//*********************		Global variables		******************************/

            public static string defaultImage = @"http://www.chameleonhome.com/Images/imageUnavailable_b.jpg";
            public static string defaultImageThumb = @"http://www.chameleonhome.com/Images/imageUnavailable_s.jpg";



                  

            public static string sendGridServer = "";
            public static string sendGridUser = "";
            public static string sendGridPw = "";



			//*********************		Global constants		******************************/


            //public mMain()
            //{
            //    //
            //    // TODO: Add constructor logic here
            //    //
            //    //mData1 = new mData();
				
            //}
	
		}
	}

